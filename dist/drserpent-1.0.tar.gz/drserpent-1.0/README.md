# Dr Serpent Documentation

## Aim:
To build a easy to use testing framework for Python.

## Contributors:
* **[Alex McCarroll](https://github.com/AlexMcCarroll)**
* **[Ricky Hewitt](https://github.com/rewitt94)**
* **[Tom Betts](https://github.com/T-Betts)**
* **[Hemesh Unka](https://github.com/Hemesh-Unka)**
